package kiosk;

public class dbVo {

	int no;
	String menu;

	// 오버로딩
	public dbVo() {
		
	}

	// 오버로딩
	public dbVo(int no, String menu) {
		this.no = no;
		this.menu = menu;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

}
